<?php
	date_default_timezone_set('Etc/UTC');
	require './PHPMailer/PHPMailerAutoload.php';
	
	$mail = new PHPMailer;
	
	$mail->IsHTML(true);
	$mail->CharSet = "text/html; charset=UTF-8;";
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Debugoutput = 'html';
	$mail->Host = 'smtp.gmail.com';
	//$mail->Host = 'relay-hosting.secureserver.net';
	
	$mail->Port = 587;
	//$mail->Port = 25;
	
	$mail->SMTPSecure = 'tls';
	//$mail->SMTPSecure = 'ssl-False';
	
	$mail->SMTPAuth = true;
	//$mail->SMTPAuth = false;
	
	$mail->Username = "spambiff@gmail.com";
	$mail->Password = "ffibmaps";
	
	$mail->setFrom('info@odishaAIMS.com', 'FullAroma');
	//$mail->addReplyTo('spambiff@gmail.com', 'spambiff');
	
	$mail->addAddress('das.dpk@gmail.com', 'Deepak');
	
	$mail->Subject = 'Testing Mail Subject';
	$mail->Body='Testing<br><br> Mail Body';
	
	//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
	//$mail->AltBody = 'This is a plain-text message body';
	//$mail->addAttachment('images/phpmailer_mini.png');
	
	if (!$mail->send()) {
		echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
		echo "Message sent!";
	}
?>