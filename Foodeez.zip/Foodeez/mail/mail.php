<?php
	date_default_timezone_set('Etc/UTC');
	require './PHPMailer/PHPMailerAutoload.php';
	
	$to='das.dpk@gmail.com';
	$name='Deepak';
	
	$mail = new PHPMailer;
	$mail->isSMTP(); 
	
	$mail->IsHTML(true);
	$mail->CharSet = "text/html; charset=UTF-8;";
	$mail->SMTPDebug = 1;
	$mail->Debugoutput = 'html';
	$mail->Host = 'relay-hosting.secureserver.net';
	$mail->SMTPAuth = false; 
	$mail->SMTPSecure = 'ssl-False';
	$mail->Port = 25;
	
	$mail->Username = "spambiff@gmail.com";
	$mail->Password = "ffibmaps";
	
	$mail->setFrom('info@odishaAIMS.com', 'FullAroma');
	$mail->addAddress($to, $name);
	$mail->Subject = 'PHPMailer GMail SMTP test';
	$mail->Body='Testing<br><br> Mail';
	
	if (!$mail->send()) {
		echo "Mailer Error: " . $mail->ErrorInfo;
	} else {
		echo "Message sent!";
	}
?>