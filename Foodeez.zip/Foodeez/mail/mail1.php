<?php
	$sender="FullAroma";
	$from="info@odishaAIMS.com";
	
	$receiver="FullAroma User";
	$to="das.dpk@gmail.com";
	
	$Message="Test Mail Body";
	$subject="Test Mail Subject";
	
	
	$headers[]="MIME-VERSION: 1.0";
	$header[]="Content-type:text/html;characterset=UTF-8";
	
	$headers[] = "To: " . $sender . " <das.dpk@gmail.com>";
	$headers[] = "From: " . $receiver . " <deepakoca@gmail.com>";
	
	if(mail($to, $subject, $Message, implode("\r\n", $headers)))
	{
		echo "Mail Sent with Sender " . $headers[2];
	}
	else
	{
		echo "Unable to Send Mail";
	}
?>