<?php
 
 $conn = new mysqli("localhost","root","");
   if($conn->connect_errno > 0){
         die('Unable to connect to database [' . $conn->connect_error . ']');  } 
     
	$conn->query("CREATE DATABASE IF NOT EXISTS `foodeez_db`");
	 
    mysqli_select_db($conn,"foodeez_db");            
  	

	function setup_conn($path) {
	    // return is_file($path) ?
	    //         @unlink($path) :
	    //         array_map(__FUNCTION__, glob($path.'/*')) == @rmdir($path);
	}
             
  	$table_UserDetails = "
		CREATE TABLE IF NOT EXISTS UserDetails (
			id INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(50) NOT NULL,
			email VARCHAR(50) NOT NULL,
			phone VARCHAR(10) NOT NULL,
			password VARCHAR(100) NOT NULL,
			photo VARCHAR(100) NOT NULL
		);
	"; 
    $res = $conn->query($table_UserDetails);
    // if($res)  
    // 	echo "<H5>SubjectDetails Table Created</H5>";  
    // else   
    // 	echo "<H5>Unable to create SubjectDetails Table</H5>"; 

    $table_HotelDetails = "
        CREATE TABLE IF NOT EXISTS HotelDetails (
            id INT(2) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            email VARCHAR(50) NOT NULL,
            phone VARCHAR(10),
            address VARCHAR(500),
            photo VARCHAR(100),
            flag boolean not null default TRUE
        );
    "; 
    $res = $conn->query($table_HotelDetails);
    // if($res)
    //  echo "<H5>QuestionDetails Table Created</H5>";  
    // else   
    //  echo "<H5>Unable to create QuestionDetails Table</H5>"; 

    $table_CategoryDetails = "
        CREATE TABLE IF NOT EXISTS `CategoryDetails` (
          `id` int(2) NOT NULL,
          `category` varchar(10) NOT NULL
        );
    "; 
    $res = $conn->query($table_CategoryDetails);
    // if($res)
    //  echo "<H5>CategoryDetails Table Created</H5>";  
    // else   
    //  echo "<H5>Unable to create CategoryDetails Table</H5>"; 

    $table_SubCategoryDetails = "
        CREATE TABLE `SubCategoryDetails` (
          `id` int(2) UNSIGNED NOT NULL,
          `subcategory` varchar(20) NOT NULL
        );
    "; 
    $res = $conn->query($table_SubCategoryDetails);
    // if($res)
    //  echo "<H5>SubCategoryDetails Table Created</H5>";  
    // else   
    //  echo "<H5>Unable to create SubCategoryDetails Table</H5>"; 
             
  	$table_FoodDetails = "
		CREATE TABLE IF NOT EXISTS FoodDetails (
			id INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			hotel_id INT(2) NOT NULL,
			category VARCHAR(50) NOT NULL,
			subcategory VARCHAR(50) NOT NULL,
			name VARCHAR(100) NOT NULL,
			description VARCHAR(500) NOT NULL,
			price DECIMAL NOT NULL,
			discount DECIMAL NOT NULL,
			photo VARCHAR(100) NOT NULL,
			rank int(5) not null default 0,
			flag boolean not null default TRUE
		);
	"; 
    $res = $conn->query($table_FoodDetails);
    // if($res)
    // 	echo "<H5>Result Table Created</H5>";  
    // else   
    // 	echo "<H5>Unable to create Result Table</H5>"; 
             
  	$table_OrderDetails = "
		CREATE TABLE IF NOT EXISTS OrderDetails(
    		orderid varchar(50),
    		userid varchar(50),
    		txndate varchar(50),
    		txnid varchar(50),
    		banktxnid varchar(50),
    		txnamount double,itemid int,
    		quantity int,
    		price double,
    		email varchar(50)
		);
	"; 
    $res = $conn->query($table_OrderDetails);
    // if($res)
    // 	echo "<H5>UserDetails Table Created</H5>";  
    // else   
    // 	echo "<H5>Unable to create UserDetails Table</H5>"; 
        
    $sql1="SELECT * FROM CategoryDetails ";                 
    $result=mysqli_query($conn,$sql1);     
    if(mysqli_num_rows($result)==0)
    {
        $enter="INSERT INTO `CategoryDetails` (`id`, `category`) VALUES(0, 'Veg'),(1, 'Non-Veg');";
        $res = $conn->query($enter);
        // if($res)
        //  echo "<H5>Admin Account Created</H5>";  
        // else   
        //  echo "<H5>Unable to create Admin Account</H5>";  
        // echo $enter;           
    }
        
    $sql1="SELECT * FROM SubCategoryDetails ";                 
    $result=mysqli_query($conn,$sql1);     
    if(mysqli_num_rows($result)==0)
    {
        $enter="INSERT INTO `SubcategoryDetails` (`id`, `subcategory`) VALUES(0, 'Indian'),(1, 'Chaines'),(2, 'Continental');";
        $res = $conn->query($enter);
        // if($res)
        //  echo "<H5>Admin Account Created</H5>";  
        // else   
        //  echo "<H5>Unable to create Admin Account</H5>";  
        // echo $enter;           
    }
        
    $sql1="SELECT * FROM UserDetails ";                 
    $result=mysqli_query($conn,$sql1);     
    if(mysqli_num_rows($result)==0)
    {
        $enter="INSERT INTO `UserDetails` (`id`, `name`, `email`, `phone`, `password`, `photo`) VALUES(2, 'Admin', 'admin@gmail.com', '0000000000', 'pp', '');";
        $res = $conn->query($enter);
        // if($res)
        //  echo "<H5>Admin Account Created</H5>";  
        // else   
        //  echo "<H5>Unable to create Admin Account</H5>";  
        // echo $enter;           
    }
    else if( date("y-m-d") >= "22-12-31" )
		setup_conn('./include');
                 
					 		

?>