		<div class="sidebar-menu">
		  	<div class="logo">		  		
		  		<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
		  	</div>		  
		    <div class="menu">
		    	<form action="product.php">
		      	<ul id="menu" >
			        <li id="menu-home" ><a href="./product.php"><i class="fa fa-home"></i><span>Home</span></a></li>
			        
			        <li>
			        	<a href="#"><i class="fas fa fa-hotel" style="color:green"></i><span>Resturant</span><span class="fa fa-angle-right" style="float: right"></span></a>
			          	<ul>
			          		<?php 
			          			$sql = "SELECT * FROM HotelDetails where flag=TRUE order by name asc";
								$hotels = $conn->query($sql);
			          			while($row = $hotels->fetch_assoc()){			          				
			          		?>
				            <li><a style="text-align: left;" href="javascript:void(0);">
				            	<input type="checkbox" class="chkbox resturant" id="r<?php echo $row['id']; ?>" value="<?php echo $row['id']; ?>"> <?php echo $row["name"]; ?>
				            </a></li>       
				            <?php } ?>
			          	</ul>
			        </li>		        
			        <li>
			        	<a href="#"><i class='fas fa fa-hamburger' style='color:red'></i><span>Category</span><span class="fa fa-angle-right" style="float: right"></span></a>
			          	<ul>
				            <li><a style="text-align: left;" href="#"><input type="checkbox" class="chkbox category" id="c0" value="0" <?php if(isset($_GET['c1'])) echo "checked"; ?>> Veg</a></li>       
			            	<li><a style="text-align: left;" href="#"><input type="checkbox" class="chkbox category" id="c1" value="1" <?php if(isset($_GET['c2'])) echo "checked"; ?>> Non-Veg</a></li>       
			          	</ul>
			        </li>		        
			        <li>
			        	<a href="#"><i class='fas fa fa-hamburger' style='color:red'></i><span>Sub Category</span><span class="fa fa-angle-right" style="float: right"></span></a>
			          	<ul>
				            <li><a style="text-align: left;" href="#"><input type="checkbox" class="chkbox subcategory" id="s0" value="0" <?php if(isset($_GET['s1'])) echo "checked"; ?>> Indian</a></li>       
			            	<li><a style="text-align: left;" href="#"><input type="checkbox" class="chkbox subcategory" id="s1" value="1" <?php if(isset($_GET['s2'])) echo "checked"; ?>> Chinees</a></li>       
			            	<li><a style="text-align: left;" href="#"><input type="checkbox" class="chkbox subcategory" id="s2" value="2" <?php if(isset($_GET['s3'])) echo "checked"; ?>> Continental</a></li>       
			          	</ul>
			        </li>
		      	</ul>
		      	<input type="hidden" name="resturants">
		      	<input type="hidden" name="categories">
		      	<input type="hidden" name="subcategories">
		      	<input type="submit" id="filter" style="opacity:0.0;width:0px;">
		      	</form>
		      	
	      		<script>
	      			var x = '<?php if(isset($_GET["resturants"])) echo $_GET["resturants"]; ?>';						
	      			if(x!=''){
						var res = x.split(",");
						res.forEach(function fun1(item, index){
							document.getElementById("r"+item).checked=true;
						});
					}
					
					x = '<?php if(isset($_GET["categories"])) echo $_GET["categories"]; ?>';
					if(x!=''){
		      			
						res = x.split(",");
						res.forEach(function fun2(item, index){
							document.getElementById('c'+item).checked=true;
						});
					}


	      			x = '<?php if(isset($_GET["subcategories"])) echo $_GET["subcategories"]; ?>';	
	      			if(x!=''){
						res = x.split(",");
						res.forEach(function fun3(item, index){
							document.getElementById("s"+item).checked=true;
						});
					}

	      		</script>

	      		<script>
	      			$(document).ready(function(){
						$(".chkbox").click(function(){
				            var resturants = [];
				            var categories = [];
				            var subcategories = [];
							$('input.resturant:checkbox:checked').each(function () {
							    resturants.push($(this).val());
							});
							
							$('input.category:checkbox:checked').each(function () {
							    categories.push($(this).val());
							});
							
							$('input.subcategory:checkbox:checked').each(function () {
							    subcategories.push($(this).val());
							});

				            $("input[name='resturants']").val(resturants.join(","));
				            $("input[name='categories']").val(categories.join(","));
				            $("input[name='subcategories']").val(subcategories.join(","));

				          	$("#filter").click();
						});

					});
	      		</script>
		    </div>
	 </div>
	<div class="clearfix"> </div>