					<div class="copyrights">
		 				<p>© <?php echo date("Y");?> Foodeez. All Rights Reserved | Design by  <a href="OdishaAIMS.com" target="_blank">OdishaAIMS</a> </p>
					</div>	