				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="<?php if($_SESSION['user']=="Admin") echo './'; else echo './product.php'; ?>"> 
									 	<!--<h1>Foodeez</h1> -->
										<img  src="./images/logo1.png" alt="Foodeez" style="height:50px;" />
								  </a> 								
							</div>
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							<div class="profile_details_left"  <?php if($_SESSION['user']=="Admin") echo 'style="display:none;"'; ?> ><!--notifications of menu start -->
								<ul class="nofitications-dropdown" style="float:right;">									
									<li class="dropdown head-dpdn">
										<a href="./my_cart.php">											
											<i class="fas fa-shopping-cart"></i>
											<span class="badge blue1" id="cart">
											<?php
												$k=0;
												if(isset($_SESSION["cart_item"]))
													$k=count($_SESSION["cart_item"]);
												echo $k;
											?>
											</span>
										</a>
									</li>	
								</ul>
								<div class="clearfix"> </div>
							</div>
							<!--notification menu end -->
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img">
													<?php 
														if(isset($_SESSION['photo']) && $_SESSION['photo']!=null)
															echo '<img style="height:50px;" src="images/p2.png"';
														else
															echo '<img style="height:50px;" src="images/user.jpg">';
													?>		
												</span> 
												<div class="user-name">
													<?php
														echo "<p>$_SESSION[user]</p>";
														if($_SESSION['user']=="Admin")
															echo "<span>Administrator</span>";
														else
															echo "<span>User</span>";
													?>
													
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<?php 
												if(strtolower($_SESSION['email']) != 'admin@gmail.com')
													echo '<li> <a href="./order_history.php"><i class="fa fa-shopping-cart"></i>Order History</a> </li> ';
											?>
											
											<li> <a href="./my_profile.php"><i class="fas fa-user-circle"></i> Profile</a> </li> 
											<li> <a href="./password_change.php"><i class="fa fa-lock"></i> Change Password</a> </li> 
											<li> <a href="./logout.php"><i class="fa fa-power-off" aria-hidden="true"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>
				
				<!-- script-for sticky-nav -->
				<script>
					$(document).ready(function() {
			 			var navoffeset=$(".header-main").offset().top;
			 			$(window).scroll(function(){
							var scrollpos=$(window).scrollTop(); 
							if(scrollpos >=navoffeset){
								$(".header-main").addClass("fixed");
							}else{
								$(".header-main").removeClass("fixed");
							}
			 			});
					});
				</script>
				<!-- /script-for sticky-nav -->