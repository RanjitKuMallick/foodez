		<div class="sidebar-menu">
		  	<div class="logo">		  		
		  		<a href="./" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
		  		 <!--
		  		<a href="./"> <span id="logo" ></span><img id="logo" src="./img1.jpg" alt="Foiodeez Logo"/></a> 
		  		-->
		  	</div>		  
		    <div class="menu">
		      <ul id="menu">
		        <li id="menu-home" ><a href="./"><i class="fa fa-home"></i><span>Dashboard</span></a></li>
		        
		        <li><a href="#"><i class="fa fa-building" style='color:green'></i><span>Resturant</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a style="text-align: left;" href="./hotel_entry.php"><i class="fas fa-plus"></i> Add</a></li>
		            <li><a style="text-align: left;" href="./hotel_view.php"><i class="fas fa-eye"></i> View</a></li>		            
		          </ul>
		        </li>

		        
		        <li><a href="#"><i class="fas fa fa-hamburger" style='color:red'></i><span>Food</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a  style="text-align: left;" href="./food_entry.php"><i class="fas fa-plus"></i> Add</a></li>
		            <li><a  style="text-align: left;" href="./food_view.php"><i class="fas fa-eye"></i> View</a></li>	
		          </ul>
		        </li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>